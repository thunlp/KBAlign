from .print_utils import print_inspect
from .net_utils import check_web_and_convert_path