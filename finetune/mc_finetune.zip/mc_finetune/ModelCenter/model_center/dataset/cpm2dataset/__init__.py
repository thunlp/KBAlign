from .down_data import *

DATASET = {
    "LCQMC": LCQMC_Dataset,
}