---
name: New model
about: Add a new model to this project
title: "[MODEL] "
labels: ''
assignees: ''

---

**Introduction**
<!-- A clear and concise description of the model and reasons for adding it. -->

**Resources**
<!-- Please provide papers, codes, and authors of the model.-->
Paper:

Code:

Author:
