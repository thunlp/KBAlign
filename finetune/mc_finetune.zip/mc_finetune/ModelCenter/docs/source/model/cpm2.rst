=======================
CPM2
=======================

`CPM2 <https://arxiv.org/pdf/2106.10715>`_

CPM2Config
------------------------------------
.. autoclass:: model_center.model.CPM2Config
   :members:

CPM2Model
------------------------------------
.. autoclass:: model_center.model.CPM2
   :members:

CPM2Tokenizer
------------------------------------
.. autoclass:: model_center.tokenizer.CPM2Tokenizer
   :members: