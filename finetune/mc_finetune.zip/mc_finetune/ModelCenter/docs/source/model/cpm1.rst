=======================
CPM1
=======================

`CPM1 <https://arxiv.org/abs/2012.00413>`_

CPM1Config
------------------------------------
.. autoclass:: model_center.model.CPM1Config
   :members:

CPM1Model
------------------------------------
.. autoclass:: model_center.model.CPM1
   :members:

CPM1Tokenizer
------------------------------------
.. autoclass:: model_center.tokenizer.CPM1Tokenizer
   :members: