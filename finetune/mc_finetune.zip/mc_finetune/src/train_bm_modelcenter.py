from transformers import LlamaConfig,LlamaForCausalLM,LlamaTokenizerFast
import json
from collections import OrderedDict
from safetensors.torch import load_file
import argparse
import torch
from ultrachat_dataset import load_raw_data, PromptIterableDataset, collator
from tqdm import tqdm
from torch.utils.data import DataLoader
import bmtrain as bmt
from functools import partial
import time
import os
import sys
sys.path.append("./ModelCenter")
from model_center.model import Llama
from model_center.tokenizer import LlamaTokenizer
#import wandb
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:128"
import logging
import shutil
import numpy as np
import math

import threading

event = threading.Event()

def wait_for_input():
    while True:
        user_input = input("输入'1'继续运行: ")
        if user_input == '1':
            print("输入成功")
            event.set()
            break
        else:
            print("输入无效，请输入'1'继续运行。")
    
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_model_tokenizer(args):
    logger.info("loading model...")
    tokenizer = LlamaTokenizerFast.from_pretrained(args.model_name_or_path)
    model = Llama.from_pretrained(args.model_name_or_path)
    logger.info("loaded")
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    if args.load_ckpt is not None:
        logger.info(f"loading model from {args.load_ckpt}")
        model.load_state_dict(torch.load(os.path.join(args.load_ckpt, "pytorch_model.pt")), strict=False)

    return model, tokenizer

def get_optimizer(args, model):
    # logger.info("set beta2=0.95") #Offload
    optimizer = bmt.optim.AdamOptimizer(
        model.parameters(), weight_decay=args.weight_decay, eps=1e-5, betas=(0.9, 0.95)
    )
    # , eps=1e-5, betas=(0.9, 0.95)
    if args.load_ckpt is not None:
        file_name = os.path.join(args.load_ckpt, "optim.rank-{}.opt".format(bmt.rank()))
        logger.info(file_name)
        if os.path.exists(file_name):
            logger.info("start to load grad ckpt {}".format(file_name))
            states = torch.load(file_name)
            optimizer.load_state_dict(states)
    # if args.start_step != 0:
        # logger.info(f"loading optimizer from step {args.start_step}")
        # optimizer.load_state_dict(torch.load(os.path.join(args.save_dir, f"ultrachat_{args.model}/step_{args.start_step}/optimizer.pt")))
    return optimizer


def get_learning_rate_scheduler(args, optimizer):
    if args.lr_decay_iters is None:
        args.lr_decay_iters = args.train_iters
    if args.lr_decay_style == "linear":
        lr_scheduler = bmt.lr_scheduler.Linear(
            optimizer,
            start_lr=args.lr,
            warmup_iter=int(args.warmup_iters),
            end_iter=args.lr_decay_iters,
            num_iter=args.start_step,
        )
    elif args.lr_decay_style == "cosine":
        bmt.print_rank("use cosine")
        class Cosine(bmt.lr_scheduler.WarmupLRScheduler):
            def get_lr_warmup(self, num_iter) -> float:
                return self.start_lr * num_iter / self.warmup_iter
                
            def get_lr_decay(self, num_iter) -> float:
                progress = (num_iter - self.warmup_iter) / max(1, (self.end_iter - self.warmup_iter))
                return max(self.start_lr * 0.1, self.start_lr * (0.1 + 0.45 * (1.0 + math.cos(progress * math.pi))))
            
        lr_scheduler = Cosine(
            optimizer,
            start_lr=args.lr,
            warmup_iter=int(args.warmup_iters),
            end_iter=args.lr_decay_iters,
            num_iter=args.start_step,
        )

    elif args.lr_decay_style == "noam":
        logger.info("use noam")
        lr_scheduler = bmt.lr_scheduler.Noam(
            optimizer,
            start_lr=args.lr,
            warmup_iter=int(args.warmup_iters),
            end_iter=args.lr_decay_iters,
            num_iter=args.start_step,
        )
    else:
        raise NotImplementedError
    
    if args.load_ckpt is not None:
        lr_scheduler.load_state_dict(torch.load(os.path.join(args.load_ckpt, f"scheduler.pt")))
        # lr_scheduler.num_iter += args.lr_add_num  
        # print(f"lr_add_num:{args.lr_add_num}")
        
    # if args.start_step != 0:
    #     logger.info(f"loading scheduler from step {args.start_step}")
    #     lr_scheduler.load_state_dict(torch.load(os.path.join(args.save_dir, f"ultrachat_{args.model}/step_{args.start_step}/scheduler.pt")))
    return lr_scheduler


def setup_model_and_optimizer(args):
    model, tokenizer = get_model_tokenizer(args)
    bmt.synchronize()
    optimizer = get_optimizer(args, model)
    lr_scheduler = get_learning_rate_scheduler(args, optimizer)
    bmt.synchronize()
    return tokenizer, model, optimizer, lr_scheduler

def save(model, model_fname):
    if os.path.exists(model_fname): os.remove(model_fname)
    # if os.path.exists(success_fname): os.remove(success_fname)
    
    temp_fname = os.path.join("/local", model_fname.strip("/"))
    if os.path.exists(temp_fname): os.remove(temp_fname)
    temp_dir = os.path.dirname(temp_fname)
    os.makedirs(temp_dir, exist_ok=True)
    logger.info(f"temp_fname: {temp_fname}")

    time1 = time.time()
    bmt.save(model, temp_fname)
    time2 = time.time()
    logger.info(f"bmt.save used {(time2 - time1)} sec")

    if bmt.rank() == 0:
        logger.info(f"src:{temp_fname} -> dst:{model_fname}")
        shutil.move(temp_fname, model_fname)
        time3 = time.time()
        logger.info(f"mv used {(time3 - time2)} sec")
        
        dir_list = os.listdir(os.path.dirname(model_fname))
        logger.info(f"{os.path.dirname(model_fname)}: {','.join(dir_list)}")
        
        # f = open(success_fname, 'w+')
        # f.write('success\n')
        # f.close()

def train(args):
    bmt.init_distributed(
        seed=args.seed,
        zero_level=3,
    )

    if args.wandb and bmt.rank() == 0:
        wandb.init()
    
    if args.tensorboard is not None and bmt.rank() == 0:
        from torch.utils.tensorboard import SummaryWriter
        import distutils.version  # noqa: F401

        if not os.path.exists(args.tensorboard):
            os.makedirs(args.tensorboard)
        writer = SummaryWriter(log_dir=args.tensorboard)

    
    
    original_dataset = []
    if args.data_dir is not None:
        logger.info(f"load ultrachat data, split={args.ultra_split}")
        original_dataset += load_raw_data(args.data_dir, max_sample=args.max_sample, random_state=0, split=args.ultra_split)

    logger.info(f"total training instance number: {len(original_dataset)}")

    #todo
    # args.train_iters = args.epochs * (len(original_dataset) // (bmt.world_size() * args.batch_size_per_device * args.gradient_accumulation_steps) + 1)
    
    args.train_iters = args.epochs * (len(original_dataset) // (bmt.world_size() * args.batch_size_per_device) + 1 )
    
    tokenizer, model, optimizer, lr_scheduler = setup_model_and_optimizer(args)
    optim_manager = bmt.optim.OptimManager(loss_scale=args.loss_scale)
    optim_manager.add_optimizer(optimizer, lr_scheduler)
    bmt.synchronize()
    

    bmt.print_rank("Model memory")
    bmt.print_rank(torch.cuda.memory_summary())

    avg_time_recorder = bmt.utils.AverageRecorder()
    avg_loss_recorder = bmt.utils.AverageRecorder()
    train_start_time = time.time()
    global_step = 0

    loss_func = bmt.loss.FusedCrossEntropy(ignore_index=-100)

    # save_dir = os.path.join(args.save_dir, f"{args.model}/step_{global_step}")
    # os.makedirs(save_dir, exist_ok=True)

    # save(model, os.path.join(save_dir, "pytorch_model.pt"))
    # bmt.save(model, os.path.join(save_dir, "pytorch_model.pt"))
    logger.info("entering trainig loop...")
    for epoch in range(args.epochs):
        logger.info("permuting data...")
        indices = torch.randperm(len(original_dataset))
        dataset = [original_dataset[i] for i in indices]

        # if epoch == 0:
        #     new_dataset = []
        #     logger.info(f"skipping samples")
        #     world_size = 128
        #     data_per_gpu = len(dataset) // world_size
        #     for j in range(world_size):
        #         dataset_tmp = dataset[j * data_per_gpu : (j + 1) * data_per_gpu][800*4:]
        #         new_dataset += dataset_tmp
        #     dataset = new_dataset

        logger.info("split data for each process")
        data_per_gpu = len(dataset) // bmt.world_size()
        dataset = dataset[bmt.rank() * data_per_gpu : (bmt.rank() + 1) * data_per_gpu]

        logger.info("wrapping up data")
        dataset = PromptIterableDataset(dataset, tokenizer = tokenizer, max_seq_length = args.max_seq_length, teacher_forcing=True, truncate_method="tail")
        dataloader = DataLoader(dataset, batch_size=args.batch_size_per_device, collate_fn=partial(collator, tokenizer))

        if global_step >= args.train_iters:
            break
        #todo
        # progress_bar = tqdm(range((len(dataloader) + args.gradient_accumulation_steps - 1) // args.gradient_accumulation_steps), disable=not bmt.rank()==0, desc=f"epoch {epoch}")
        progress_bar = tqdm(range(len(dataloader)), disable=not bmt.rank()==0, desc=f"epoch {epoch}")
        logger.info(f"*******start {epoch} epoch training********")
        for step, inputs in enumerate(dataloader):
            if global_step < args.start_step:
                # print(f"skip step {global_step}!")
                global_step += 1
                progress_bar.update(1)
                continue
            st = time.time()

            with bmt.inspect.inspect_tensor() as inspector:
                for k in inputs:
                    inputs[k] = inputs[k].cuda()
                labels = inputs.pop("labels")
                logits = model(**inputs).logits

                shift_logits = logits[..., :-1, :].contiguous()
                shift_labels = labels[..., 1:].contiguous()
                # Flatten the tokens
                shift_logits = shift_logits.view(-1, len(tokenizer))
                shift_labels = shift_labels.view(-1)
                # Enable model parallelism
                shift_labels = shift_labels.to(shift_logits.device)
                # print("logits:", shift_logits[:5, :10])
                # print("labels:", shift_labels[:10])
                loss = loss_func(shift_logits, shift_labels)
                # print(f"rank: {bmt.rank()}, loss: {loss.item()}")
                # loss = output.loss
                # loss = loss_func(logits, labels)
            
                global_loss = bmt.sum_loss(loss).item()

                optim_manager.backward(loss)


                if (step + 1) % args.gradient_accumulation_steps == 0 or step == len(dataloader) - 1:
                    optim_manager.clip_grad_norm(optimizer.param_groups, max_norm=args.clip_grad)

                    optim_manager.step()
                    optim_manager.zero_grad()
                    
                    # progress_bar.update(1)
                    # global_step += 1
            
            global_step += 1
            progress_bar.update(1)
            
            # record time and loss
            iteration_time = time.time() - st

            avg_time_recorder.record(iteration_time)
            if not np.isnan(global_loss):
                avg_loss_recorder.record(global_loss)

            # print time and loss
            if global_step % args.logging_step == 0:
                bmt.print_rank(
                    "| Iter: {:6d} | loss: {:.4f} average_loss: {:.4f} | lr: {:.4e} | lr_num_iter: {:} | time: {:.4f} seconds | total_time_passed: {:.4f} minutes".format(
                        global_step,
                        global_loss,
                        avg_loss_recorder.value,
                        lr_scheduler.current_lr,
                        lr_scheduler.num_iter,
                        avg_time_recorder.value,
                        (time.time() - train_start_time) / 60
                    )
                )
                if args.wandb and bmt.rank() == 0:
                    wandb.log({
                        "loss": global_loss,
                        "average_loss": avg_loss_recorder.value,
                        "lr": lr_scheduler.current_lr,
                    }, step=global_step)
                if args.tensorboard and bmt.rank() == 0:
                    writer.add_scalar("Loss/train", global_loss, global_step)
                    writer.add_scalar("average_Loss/train", avg_loss_recorder.value, global_step)
                    writer.add_scalar("lr/train", lr_scheduler.current_lr, global_step)
                    # if global_step==0:
                    #     writer.add_scalar("epoch/train", 0, global_step)
                    # else:
                    #     writer.add_scalar("epoch/train", args.train_iters/global_step, global_step)


            # save model
            if global_step % args.save_step == 0:
                try_time = 0
                while try_time < 10:
                    try:
                        save_dir = os.path.join(args.save_dir, f"{args.model}/step_{global_step}")
                        os.makedirs(save_dir, exist_ok=True)

                        bmt.save(model, os.path.join(save_dir, "pytorch_model.pt"))
                        # save(model, os.path.join(save_dir, "pytorch_model.pt"))
                        print("saving optimizer state", str(os.path.join(save_dir, "optim.rank-%d.opt" % bmt.rank())))
                        torch.save(optimizer.state_dict(),
                                os.path.join(save_dir, "optim.rank-%d.opt" % bmt.rank()))

                        if bmt.rank() == 0:
                            # torch.save(optimizer.state_dict(), os.path.join(save_dir, "optimizer.pt"))
                            

                            torch.save(lr_scheduler.state_dict(), os.path.join(save_dir, "scheduler.pt"))
                            tokenizer.save_pretrained(save_dir)
                        bmt.print_rank(f"model saved at {save_dir}")

                        
                    except Exception as e:
                        try_time += 1
                        continue
                    else:
                        break
                        
                if bmt.rank() == 0:
                    if args.save_limit is not None:
                        output_dir = os.path.join(args.save_dir, args.model)
                        files = os.listdir(output_dir)
                        ckpt_id = list(sorted([int(f[5:]) for f in files if f.startswith("step_") and "_hf" not in f], reverse=True))
                        for i in ckpt_id[args.save_limit:]:
                            path = os.path.join(output_dir, f"step_{i}")
                            if not os.path.exists(os.path.join(output_dir, f"step_{i}_hf")):
                                shutil.rmtree(path)
                # todo
                # sys.exit(0)

            if global_step == args.train_iters:
                break
    
    # bmt.save(model, os.path.join(args.save_dir, f"final.pt"))

  


def mapping_function(bm_key):
        if bm_key == "input_embedding.weight":
            return "model.embed_tokens.weight"

        elif bm_key == "encoder.output_layernorm.weight":
            return "model.norm.weight"

        elif bm_key == "output_projection.weight":
            return "lm_head.weight"

        elif "encoder.layers." in bm_key:
            lnum = bm_key.split(".")[2]
            if "self_att.layernorm_before_attention.weight" in bm_key:
                return f"model.layers.{lnum}.input_layernorm.weight"
            elif "self_att.self_attention.project_q.weight" in bm_key:
                return f"model.layers.{lnum}.self_attn.q_proj.weight"
            elif "self_att.self_attention.project_k.weight" in bm_key:
                return f"model.layers.{lnum}.self_attn.k_proj.weight"
            elif "self_att.self_attention.project_v.weight" in bm_key:
                return f"model.layers.{lnum}.self_attn.v_proj.weight"
            elif "self_att.self_attention.attention_out.weight" in bm_key:
                return f"model.layers.{lnum}.self_attn.o_proj.weight"
            elif "ffn.layernorm_before_ffn.weight" in bm_key:
                return f"model.layers.{lnum}.post_attention_layernorm.weight"
            elif "ffn.ffn.w_in.w_0.weight" in bm_key:
                return f"model.layers.{lnum}.mlp.gate_proj.weight"
            elif "ffn.ffn.w_in.w_1.weight" in bm_key:
                return f"model.layers.{lnum}.mlp.up_proj.weight"
            elif "ffn.ffn.w_out.weight" in bm_key:
                return f"model.layers.{lnum}.mlp.down_proj.weight"
        return None

if __name__ == "__main__":
    parser = argparse.ArgumentParser("")
    parser.add_argument("--lr", type=float, default=1e-5)
    parser.add_argument("--model", type=str, default='llama-13b')
    parser.add_argument("--model_name_or_path")
    parser.add_argument("--epochs", default=3, type=int)
    parser.add_argument("--seed", default=0, type=int)

    parser.add_argument("--max_seq_length", default=2048, type=int)
    parser.add_argument("--batch_size_per_device", default=2, type=int)
    parser.add_argument("--logging_step", default=100, type=int)
    parser.add_argument("--save_step", default=50000, type=int)
    parser.add_argument("--data_dir", default=None, type=str)
    parser.add_argument("--ultra_split", default=None, type=str)

    parser.add_argument("--sharegpt_data_file", default=None, type=str)
    parser.add_argument("--reasoning_data_dir", default=None, type=str)
    parser.add_argument("--zh_data_file", default=None, type=str)

    parser.add_argument("--sharegpt4_data_file", default=None, type=str)
    parser.add_argument("--orca_data_dir", default=None, type=str)




    parser.add_argument("--gradient_accumulation_steps", default=1, type=int)
    parser.add_argument("--wandb", action="store_true")
    parser.add_argument("--with_eval", action="store_true")

    parser.add_argument("--clip-grad", type=float, default=1.0, help="gradient clipping")
    # Learning rate.
    parser.add_argument("--weight-decay", type=float, default=0.0, help="weight decay rate")
    parser.add_argument("--loss-scale", type=float, default=6553600, help="loss scale")

    parser.add_argument("--train-iters", type=int, default=2000000)

    parser.add_argument("--save_dir", type=str)

    parser.add_argument("--max_sample", type=int, default=None, help="max training sample num for ultrachat")
    parser.add_argument("--save_limit", type=int, default=None, help="ckpt saved limit number")




    parser.add_argument(
        "--warmup_iters",
        type=int,
        default=1000,
    )
    parser.add_argument(
        "--lr-decay-style",
        type=str,
        default="cosine",
        choices=["constant", "linear", "cosine", "exponential", "noam"],
        help="learning rate decay function",
    )
    parser.add_argument("--lr-decay-iters", type=int, default=None, help="lr decay steps")
    parser.add_argument(
        "--start-step", type=int, default=0, help="step to start or continue training"
    )
    parser.add_argument("--tensorboard", type=str, default=None, help="lr decay steps")
    parser.add_argument("--load_ckpt", type=str, default=None, help="resumed ckpt")
    parser.add_argument("--local_rank", type=str,default=None)
    parser.add_argument("--lr_add_num", type=int,default=None)

    args = parser.parse_args()

    train(args)
    args.model = args.model_name_or_path.split("/")[-1]
    logger.info(args.model)
