#!/bin/bash

python scripts/pissa_init.py \
    --model_name_or_path meta-llama/Meta-Llama-3-8B-Instruct \
    --output_dir models/llama3-8b-pissa
